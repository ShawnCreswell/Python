## Flask Routes

```
mkdir flask_routes
cd flask_routes
```

```
pipenv install flask
pipenv shell

```
- [ ] make [server.py](server.py)
- [ ] make [index.html](templates/index.html)