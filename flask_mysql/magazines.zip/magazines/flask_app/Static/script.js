function likes(element) {
    element.innerText++;
}

function unlike(element) {
    element.innerText--;
}
