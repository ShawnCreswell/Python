[python -m] pipenv install flask pymysql
[python -m] pipenv shell


[server.py](server.py)
[user.py](user.py)
[mysqlconnection.py](mysqlconnection.py)

